// POST /.netlify/functions/submit
// Body: { pw, request }
// Verifies the password, then triggers the GitHub Actions workflow (workflow_dispatch)
// that runs Claude on the request and opens a pull request.

const OWNER    = process.env.GITHUB_OWNER;        // e.g. "bulentmcan"
const REPO     = process.env.GITHUB_REPO;         // e.g. "my-site"
const BRANCH   = process.env.GITHUB_BASE_BRANCH || "main";
const WORKFLOW = process.env.WORKFLOW_FILE || "claude-box.yml";
const TOKEN    = process.env.GITHUB_TOKEN;        // fine-grained PAT with Actions: read+write
const PASSWORD = process.env.APP_PASSWORD;

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return json(405, { error: "Method not allowed" });
  }
  if (!TOKEN || !OWNER || !REPO || !PASSWORD) {
    return json(500, { error: "Server is not fully configured. Check environment variables." });
  }

  let body;
  try { body = JSON.parse(event.body || "{}"); }
  catch { return json(400, { error: "Bad request" }); }

  if (!body.pw || body.pw !== PASSWORD) {
    return json(401, { error: "Unauthorized" });
  }

  const request = String(body.request || "").trim();
  if (!request) return json(400, { error: "Empty request" });
  if (request.length > 4000) return json(400, { error: "Request is too long." });

  // A short, unique ticket id we can find the run by later.
  const ticket = "box-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 6);

  const url = `https://api.github.com/repos/${OWNER}/${REPO}/actions/workflows/${WORKFLOW}/dispatches`;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${TOKEN}`,
      "Accept": "application/vnd.github+json",
      "X-GitHub-Api-Version": "2022-11-28",
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      ref: BRANCH,
      inputs: { request, ticket },
    }),
  });

  if (res.status !== 204) {
    const detail = await res.text();
    return json(502, { error: `GitHub rejected the request (${res.status}). ${short(detail)}` });
  }

  return json(200, { ok: true, ticket });
};

function json(code, obj) {
  return { statusCode: code, headers: { "Content-Type": "application/json" }, body: JSON.stringify(obj) };
}
function short(s) { try { const o = JSON.parse(s); return o.message || ""; } catch { return ""; } }
