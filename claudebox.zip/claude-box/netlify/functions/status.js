// GET /.netlify/functions/status?pw=...
// Verifies the password, reads recent workflow runs + pull requests from GitHub,
// and returns a simple traffic-light status for each "Change Box" submission.

const OWNER    = process.env.GITHUB_OWNER;
const REPO     = process.env.GITHUB_REPO;
const WORKFLOW = process.env.WORKFLOW_FILE || "claude-box.yml";
const TOKEN    = process.env.GITHUB_TOKEN;
const PASSWORD = process.env.APP_PASSWORD;
const STUCK_MINUTES = Number(process.env.STUCK_MINUTES || 20);

exports.handler = async (event) => {
  const pw = (event.queryStringParameters || {}).pw;
  if (!PASSWORD || pw !== PASSWORD) return json(401, { error: "Unauthorized" });
  if (!TOKEN || !OWNER || !REPO) return json(500, { error: "Server is not configured." });

  const gh = (path) => fetch(`https://api.github.com/repos/${OWNER}/${REPO}${path}`, {
    headers: {
      "Authorization": `Bearer ${TOKEN}`,
      "Accept": "application/vnd.github+json",
      "X-GitHub-Api-Version": "2022-11-28",
    },
  });

  try {
    const [runsRes, prsRes] = await Promise.all([
      gh(`/actions/workflows/${WORKFLOW}/runs?event=workflow_dispatch&per_page=25`),
      gh(`/pulls?state=all&per_page=50&sort=created&direction=desc`),
    ]);
    if (runsRes.status === 404) return json(200, { items: [] }); // workflow not added yet
    if (!runsRes.ok) return json(502, { error: `GitHub error ${runsRes.status}` });

    const runs = (await runsRes.json()).workflow_runs || [];
    const prs  = prsRes.ok ? (await prsRes.json()) : [];
    const now  = Date.now();

    const items = runs.map((run) => {
      const ticket = extractTicket(run.name) || extractTicket(run.display_title);
      const request = extractRequest(run.name) || run.display_title || "Change request";
      const pr = ticket ? findPr(prs, ticket) : null;
      const stage = computeStage(run, pr, now);
      return {
        ticket,
        request,
        ts: Date.parse(run.run_started_at || run.created_at) || null,
        color: stage.color,
        stageLabel: stage.label,
        note: stage.note || null,
        prUrl: pr ? pr.html_url : null,
        runUrl: run.html_url,
      };
    });

    return json(200, { items });
  } catch (e) {
    return json(502, { error: "Could not reach GitHub." });
  }
};

// Run names look like:  Box · box-xxxx · <request text>
function extractTicket(name) {
  if (!name) return null;
  const m = String(name).match(/\b(box-[a-z0-9]+-[a-z0-9]+)\b/i);
  return m ? m[1] : null;
}
function extractRequest(name) {
  if (!name) return null;
  const parts = String(name).split(" · ");
  return parts.length >= 3 ? parts.slice(2).join(" · ") : null;
}
function findPr(prs, ticket) {
  return prs.find((p) =>
    (p.head && p.head.ref && p.head.ref.indexOf(ticket) !== -1) ||
    (p.title && p.title.indexOf(ticket) !== -1) ||
    (p.body && p.body.indexOf(ticket) !== -1)
  ) || null;
}

function computeStage(run, pr, now) {
  // Failed / cancelled
  if (run.status === "completed" && run.conclusion && run.conclusion !== "success") {
    return { color: "red", label: "Failed — needs attention" };
  }
  // Queued / waiting to start
  if (["queued", "requested", "waiting", "pending"].includes(run.status)) {
    return { color: "blue", label: "Submitted — queued" };
  }
  // Running
  if (run.status === "in_progress") {
    const started = Date.parse(run.run_started_at || run.created_at);
    const mins = started ? (now - started) / 60000 : 0;
    if (mins > STUCK_MINUTES) {
      return { color: "orange", label: "Still working…", note: "Taking longer than usual — may be stuck." };
    }
    return { color: "amber", label: "Claude is working…" };
  }
  // Completed successfully
  if (pr) {
    if (pr.merged_at) return { color: "green", label: "Merged — deploying to your site" };
    if (pr.state === "closed") return { color: "grey", label: "PR closed without merging" };
    return { color: "green", label: "Pull request ready to review" };
  }
  return { color: "grey", label: "Finished — no code change was needed" };
}

function json(code, obj) {
  return {
    statusCode: code,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
    body: JSON.stringify(obj),
  };
}
