# Change Box

A private web page with a box you type into. You describe a small fix, hit
send, and Claude makes the change on your project and opens a pull request for
you to review. A live traffic-light status page shows you exactly where each
request is — so you're never sitting there wondering if it got stuck.

This is for **small, well-described changes**. For bigger builds, keep using
Claude Code directly.

---

## How it works (the short version)

1. You type a request into the box and hit **Send to Claude**.
2. The page tells GitHub to start a job.
3. On GitHub's servers, Claude reads your project, makes the change on a new
   branch, and opens a **pull request**.
4. Netlify automatically builds a **preview** of that pull request.
5. The status page shows the live stage:
   **Submitted → Working → Pull request ready → Merged → Deploying.**
   If something runs too long, it flags it as possibly stuck.
6. You review the pull request, click merge when happy, and your site updates.

Because everything runs in the cloud, it works even when your computer is off.
Nothing goes live until *you* merge.

---

## What you need to set up (about 15–20 minutes, one time)

You'll need three accounts you already have or can make for free: **GitHub**
(where your code lives), **Netlify** (already connected), and the **Anthropic
Console** (for an API key that pays for the cloud runs).

> The steps below are the ones only you can do, because they're tied to your
> logins. Do them once and you're set.

### 1. Connect Claude to your project repo
- In a Claude Code terminal, run `/install-github-app` and pick your project's
  repository. This installs the Claude GitHub App (it asks for Contents,
  Issues, and Pull requests permissions — all needed to open PRs).
- If you'd rather do it by hand: install the app from
  https://github.com/apps/claude onto your repo.

### 2. Add your Anthropic API key to the repo
- Get an API key from https://console.anthropic.com (Settings → API Keys).
  **Note:** cloud runs bill to this API key, which is separate from a Claude
  subscription.
- In your project repo on GitHub: **Settings → Secrets and variables →
  Actions → New repository secret**.
- Name it exactly `ANTHROPIC_API_KEY` and paste the key as the value.

### 3. Add the workflow file to your project repo
- Copy `github-workflow/claude-box.yml` from this package into your project
  repo at this exact path: `.github/workflows/claude-box.yml`
- Commit and push it to your default branch (usually `main`).

### 4. Make a GitHub token for the app
This lets the Change Box app start jobs and read status.
- Go to GitHub → **Settings → Developer settings → Personal access tokens →
  Fine-grained tokens → Generate new token**.
- **Resource owner:** you. **Repository access:** only your project repo.
- **Permissions:** Actions → **Read and write**; Contents → Read;
  Pull requests → Read; Metadata → Read (auto).
- Generate it and copy the token (starts with `github_pat_`). You'll paste it
  into Netlify in the next step.

### 5. Deploy the app to Netlify
- Put this whole `claude-box` folder in its own GitHub repo (separate from your
  project), then in Netlify: **Add new site → Import an existing project** and
  pick it. (No build command needed — Netlify reads `netlify.toml`.)
- Or drag-and-drop deploy: `netlify deploy` from this folder if you use the CLI.
- Then set the environment variables below.

### 6. Set the app's environment variables in Netlify
In Netlify: **Site configuration → Environment variables**, add:

| Name | Value |
|------|-------|
| `GITHUB_OWNER` | your GitHub username or org (e.g. `bulentmcan`) |
| `GITHUB_REPO` | your project repo name (e.g. `my-site`) |
| `GITHUB_TOKEN` | the fine-grained token from step 4 |
| `APP_PASSWORD` | any password you choose — this locks the box to you |
| `GITHUB_BASE_BRANCH` | *(optional)* default branch, defaults to `main` |
| `WORKFLOW_FILE` | *(optional)* defaults to `claude-box.yml` |
| `STUCK_MINUTES` | *(optional)* flag "stuck" after N minutes, default `20` |

Redeploy the site after adding these (Netlify → Deploys → Trigger deploy).

### 7. Try it
Open your Netlify site URL, enter your `APP_PASSWORD`, and send a tiny test
request like *"add a comment saying hello at the top of the README"*. Watch the
status page move through the stages, then review the pull request GitHub opens.

---

## Files in this package

```
claude-box/
├── public/index.html            The box + traffic-light status page
├── netlify/functions/
│   ├── submit.js                Starts a job (checks your password first)
│   └── status.js                Reads live status from GitHub
├── netlify.toml                 Netlify config
├── github-workflow/claude-box.yml   → copy into YOUR project repo
└── README.md                    This file
```

## Notes & safety

- **Only you can use it.** Every request checks your `APP_PASSWORD`, server-side.
  Your GitHub token and API key live only on Netlify's servers — never in the
  browser.
- **Nothing goes live automatically.** Claude only opens pull requests; you
  merge them. Netlify's preview lets you see the change first.
- **Costs.** Each run uses a little GitHub Actions time and some Anthropic API
  credit (billed to your `ANTHROPIC_API_KEY`). Small changes are cheap.
- **If a request looks stuck**, the status page flags it after ~20 minutes. You
  can open the run on GitHub (Actions tab) to see logs or cancel it.
